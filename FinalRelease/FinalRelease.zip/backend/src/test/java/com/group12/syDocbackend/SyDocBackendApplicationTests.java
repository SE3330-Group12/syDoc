package com.group12.syDocbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SyDocBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
