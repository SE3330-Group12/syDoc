<template>
  <div>
    <Header></Header>
    <Help />
  </div>
</template>

<script>
import Header from "../../components/header.vue";
import Help from "../../components/help.vue";
export default {
    components:{
        Header,
        Help,
    },
  data () {
    return {}
  },
  methods: {},
}
</script>
<style scoped>
</style>
