<template>
<div class="bg_footer">
      <p>© 2022 Powered by SyDoc | 简体中文 | Privacy and Terms | 安全性 | 联系我们 | 关于博客</p>
</div>
</template>   

<script>
export default {};
</script>

<style scoped>
.bg_footer {
  width: 100%;
  height: 100%;
  /* background:   #79bbff; */
}

/* .bg_footer .footer {
  background-color:   #79bbff;
  bottom: 0px;
  left: auto;
  margin: 0 auto;
} */

.bg_footer p {
  position: relative;
  top:10px;
  font-size: 14px;
  color: rgb(255, 255, 255);
  margin: 0 auto;
}
</style>